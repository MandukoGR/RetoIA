// SimpleCalculator.java
public class SimpleCalculator {
  public static void main(String[] args) {
    int num1 = 10;
    int num2 = 5;
    
    // Perform addition
    int sum = num1 + num2;
    
    // Perform multiplication
    int product = num1 * num2;
    
    System.out.println("Sum of " + num1 + " and " + num2 + " is: " + sum);
    System.out.println("Product of " + num1 + " and " + num2 + " is: " + product);
  }
}